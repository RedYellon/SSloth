using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Restore purchases, resotred event will be fired for ectach restored purchase")]
	public class ISN_RestorePurchases : FsmStateAction {
		
				


		public FsmString[] restoredProducts;
		public FsmString   currentRestoredItem;

		[Tooltip("Event fired when Store Kit product restored")]
		public FsmEvent successEvent;
		
		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent failEvent;

		[Tooltip("Event fired when Store Kit purchase is failed")]
		public FsmEvent ItemRestoredEvent;


		private List<FsmString> restoredProductsCash =  new List<FsmString>();


		public override void Reset() {
			restoredProductsCash = new List<FsmString>();
		}


		public override void OnEnter() {

			new IOSBillingInitChecker(OnBillingInit);

			#if UNITY_EDITOR
			Fsm.Event(successEvent);
			Finish();
			return;
			#endif
			
		}

		private void OnBillingInit() {
			IOSInAppPurchaseManager.instance.addEventListener(IOSInAppPurchaseManager.PRODUCT_BOUGHT, OnPurchase);
			IOSInAppPurchaseManager.instance.addEventListener(IOSInAppPurchaseManager.RESTORE_TRANSACTION_FAILED, OnFailed);
			IOSInAppPurchaseManager.instance.addEventListener(IOSInAppPurchaseManager.RESTORE_TRANSACTION_COMPLETE, OnComplete);
			IOSInAppPurchaseManager.instance.restorePurchases();
		}


		private void OnPurchase(CEvent e) {

			IOSStoreKitResponse resp = e.data as IOSStoreKitResponse;
			restoredProductsCash.Add(resp.productIdentifier);
			currentRestoredItem.Value = resp.productIdentifier;
			Debug.Log("OnPurchase fired" + currentRestoredItem.Value);
			Fsm.Event(ItemRestoredEvent);
		}

		private void OnComplete() {
			Debug.Log("OnComplete fired");
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.PRODUCT_BOUGHT, OnPurchase);
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.TRANSACTION_FAILED, OnFailed);
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.RESTORE_TRANSACTION_COMPLETE, OnComplete);


			restoredProducts = restoredProductsCash.ToArray ();
			Fsm.Event(successEvent);
			Finish();
			
		}
		
		private void OnFailed() {
			Debug.Log("OnFailed fired");
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.PRODUCT_BOUGHT, OnPurchase);
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.TRANSACTION_FAILED, OnFailed);
			IOSInAppPurchaseManager.instance.removeEventListener(IOSInAppPurchaseManager.RESTORE_TRANSACTION_COMPLETE, OnComplete);
			
			Fsm.Event(failEvent);
			Finish();
			
		}
		
	}
}




