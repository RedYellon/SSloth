﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_FB_Analitycs_Rated : FsmStateAction {
		
		public FsmInt rating;
		public FsmString contentType;
		public FsmString contentId;
		public FsmInt maxRating;
		
		public override void OnEnter() {
			SPFacebookAnalytics.Rated(rating.Value, contentType.Value, contentId.Value, maxRating.Value);
			Finish ();
		}		
	}
}
