using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Billing")]
	[Tooltip("Check if the context allows for payments to be made")]
	public class ISN_IsInAppsEnabled : FsmStateAction {

		[RequiredField]
		[UIHint(UIHint.Variable)]
		public FsmBool canMakePayments;
		
		public FsmEvent canMakePaymentsEvent;
		public FsmEvent canNotMakePaymentsEvent;
		
		public override void Reset() {
			canMakePayments = false;
			canMakePaymentsEvent = null;
			canNotMakePaymentsEvent = null;
		}
		
		public override void OnEnter() {

			bool IsInEdditorMode = false;

			#if UNITY_EDITOR_OSX || UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			if(IsInEdditorMode) {
				canMakePayments.Value = true;
				Fsm.Event(canMakePaymentsEvent);

				Finish();
				return;
			}
						
			new IOSBillingInitChecker(OnBillingInit);

		}

		private void OnBillingInit() {
			bool cando = IOSInAppPurchaseManager.instance.IsInAppPurchasesEnabled;
			canMakePayments.Value = cando;
			
			if(cando) {
				Fsm.Event(canMakePaymentsEvent);
			} else {
				Fsm.Event(canNotMakePaymentsEvent);
			}

			Finish();
		}
		
	}
}


