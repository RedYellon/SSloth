﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Pop-ups")]
	[Tooltip("Shows Native preloader and lock all user interactios")]
	public class ISN_ShowPreloader : FsmStateAction {

		
		public override void OnEnter() {
			IOSNativeUtility.ShowPreloader();
		}

		
	}
}


